# python3 ./number.py 42

import sys

number = sys.argv[1]

print("From process of rank 0 the passnumber is", number)


